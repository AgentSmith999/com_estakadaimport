<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;

require_once JPATH_ADMINISTRATOR . '/components/com_estakadaimport/helpers/estakadaimport.php';

Factory::getApplication()->bootComponent('com_estakadaimport');